

public class Lyric {
    public String lyric;
    public long startTick;
    public long endTick;
}
